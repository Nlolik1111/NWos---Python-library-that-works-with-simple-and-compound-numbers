from .nwos import isPrime, isComposite, check_list_prime
